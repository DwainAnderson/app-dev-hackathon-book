//
//  FrontendBookAppApp.swift
//  FrontendBookApp
//
//  Created by Naif Albasheer on 29/04/2024.
//

import SwiftUI

@main
struct FrontendBookAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
